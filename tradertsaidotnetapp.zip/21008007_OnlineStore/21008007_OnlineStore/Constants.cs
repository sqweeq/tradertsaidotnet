﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _21008007_OnlineStore
{
    public class Constants
    {
        public const string ProductImagePath = "~/Content/ProductImages/";
        public const string ProductThumbnailPath = "~/Content/ProductImages/Thumbnails/";
        public const int PagedItems = 4;
        public const int NumberOfProductImages = 5;

    }
}