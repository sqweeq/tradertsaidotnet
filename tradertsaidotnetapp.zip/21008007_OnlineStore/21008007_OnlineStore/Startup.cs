﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(_21008007_OnlineStore.Startup))]
namespace _21008007_OnlineStore
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
