﻿using _21008007_OnlineStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace _21008007_OnlineStore.Controllers
{
    public class HomeController : Controller
    {
        private StoreContext db = new StoreContext();

        public ActionResult Index()
        {
   

            return View(db.Products.ToList());
        }

        public ActionResult About(string id)
        {
            ViewBag.Message = "Your application description page.You entered the ID "+ id;

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

    }
}