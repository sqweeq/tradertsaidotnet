namespace _21008007_OnlineStore.Migrations
{
    using _21008007_OnlineStore.Models;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<_21008007_OnlineStore.Models.StoreContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(_21008007_OnlineStore.Models.StoreContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

            var categories = new List<Category>
            {
                new Category {Name = "Vegetable"},
                new Category {Name = "Fruit"},
                new Category {Name = "Meat"},
                new Category {Name = "Seafood"},
                new Category {Name = "Dairy"},
                new Category {Name = "Frozen"},
                new Category {Name = "Beer and Wine"},
                new Category {Name = "Confectionary"},
                new Category {Name = "Deli"},
                new Category {Name = "Household"},
            };
            categories.ForEach(c => context.Categories.AddOrUpdate(p => p.Name, c));
            context.SaveChanges();

            var products = new List<Product>
            {
                new Product {Name = "Spinach", Description="Freshly picked spinach leaves washed and ready to eat 150g", Price = 5.99M, CategoryID= categories.Single(c=>c.Name == "Vegetable").ID},
                new Product {Name = "Broccolli", Description="Broccoli is a healthy and popular vegetable that has good sources of vitamin C Price is for one whole brocolli", Price = 2.00M, CategoryID= categories.Single(c=>c.Name == "Vegetable").ID},
                new Product {Name = "Banana", Description="Banana is a healthy fruit packed with vitamins and minerals and several other nutrients 850g", Price = 3.69M, CategoryID= categories.Single(c=>c.Name == "Fruit").ID},
                new Product {Name = "Beef Sirloin Steak", Description="NZ grown Beef Sirloin Steak priced per kg", Price =33.90M, CategoryID= categories.Single(c=>c.Name == "Meat").ID},
                new Product {Name = "Fresh Maine Lobster each", Description="Freshly imported Maine Lobsters priced each lobster", Price =59.99M, CategoryID= categories.Single(c=>c.Name == "Seafood").ID},
                new Product {Name = "Frozen Hawaiian Pizza", Description="Freshly frozen Hawaiian pizza 850g packed with ham and pineapple for your pizza cravings", Price =11.99M, CategoryID= categories.Single(c=>c.Name == "Frozen").ID},
                new Product {Name = "Toilet Paper", Description="Toilet paper for daily use extra soft 12 pack", Price =15.69M, CategoryID= categories.Single(c=>c.Name == "Household").ID},
               new Product {Name = "Komoni Air Fryer Deluxe", Description="Air Fryer that can cook poultry or seafood or vegetables and is easy to wash", Price =129.99M, CategoryID= categories.Single(c=>c.Name == "Household").ID},
                new Product {Name = "Fresh Snapper", Description="Fresh Snapper that is snap frozen, guaranteed fresh price is per KG", Price =49.99M, CategoryID= categories.Single(c=>c.Name == "Seafood").ID},
               new Product {Name = "Turkey Ham", Description="Turkey ham from farmed grass fed turkey 850g", Price =11.49M, CategoryID= categories.Single(c=>c.Name == "Deli").ID},
               new Product {Name = "Tom Lee Beer", Description="NZ brewed beer with hints of barley and ginger 5 percent alcohol content 24 pack", Price =25.99M, CategoryID= categories.Single(c=>c.Name == "Beer and Wine").ID},
               new Product {Name = "Chocolates", Description="Chocolates made from dariy fresh cream premium quality 250g", Price =5.99M, CategoryID= categories.Single(c=>c.Name == "Confectionary").ID},
              new Product {Name = "White Chocolate puffs", Description="Delicious white chocolate puffs 450g", Price =9.99M, CategoryID= categories.Single(c=>c.Name == "Confectionary").ID},


            };
            products.ForEach(c => context.Products.AddOrUpdate(p => p.Name, c));
            context.SaveChanges();


            var orders = new List<Order>
                 {
                 new Order { DeliveryAddress = new Address { AddressLine1="1 Some Street",
                Town="Town1",
                 Country="Country", PostCode="PostCode" }, TotalPrice=631,
                 UserID="admin@example.com", DateCreated=new DateTime(2014, 1, 1) ,
                 DeliveryName="Admin" },
                 new Order { DeliveryAddress = new Address { AddressLine1="1 Some Street",
                Town="Town1",
                 Country="Country", PostCode="PostCode" }, TotalPrice=239,
                 UserID="admin@example.com", DateCreated=new DateTime(2014, 1, 2) ,
                 DeliveryName="Admin" },
                 new Order { DeliveryAddress = new Address { AddressLine1="1 Some Street",
                Town="Town1",
                 Country="Country", PostCode="PostCode" }, TotalPrice=239,
                 UserID="admin@example.com", DateCreated=new DateTime(2014, 1, 3) ,
                 DeliveryName="Admin" }
                 };
            orders.ForEach(c => context.Orders.AddOrUpdate(o => o.DateCreated, c));
            context.SaveChanges();
                            var orderLines = new List<OrderLine>
                 {
                 new OrderLine { OrderID = 1, ProductID = products.Single( c=> c.Name ==
                "Banana").ID,
                 ProductName ="Banana", Quantity =1, UnitPrice=products.Single( c=>
                c.Name == "Banana").Price },
                 new OrderLine { OrderID = 2, ProductID = products.Single( c=> c.Name == "Beef Sirloin Steak").ID,
                 ProductName="Beef Sirloin Steak", Quantity=1, UnitPrice=products.Single( c=> c.Name
                =="Beef Sirloin Steak").Price },
                 new OrderLine { OrderID = 3, ProductID = products.Single( c=> c.Name == "Chocolates").ID,
                 ProductName ="Chocolates", Quantity=1, UnitPrice=products.Single( c=>
                c.Name == "Chocolates").Price }
                 };
            orderLines.ForEach(c => context.OrderLines.AddOrUpdate(ol => ol.OrderID, c));
            context.SaveChanges();

        }
    }
}
